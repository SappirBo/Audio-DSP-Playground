from .audio_process_lib import *

__doc__ = audio_process_lib.__doc__
if hasattr(audio_process_lib, "__all__"):
    __all__ = audio_process_lib.__all__